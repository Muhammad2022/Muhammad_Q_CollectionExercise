import UIKit

var someStrs: [String] = ["I like to collect"]

someStrs.append ("caps")
someStrs.append("money")
someStrs += ["keys"]
    for item in someStrs {
    print(item)
    }
